# TDB Personal AI Assistant — Ultimate Edition v3.0

**Official Brand:** TDB  
**Founder:** Deep Barmon  
**Creator:** Deep Barmon (দীপ বর্মন)  
**Official Vlog YouTube Channel:** Deep Barmon Bhai Vlog  
**App Name:** TDB Personal AI Assistant  
**Platform:** Native Android (Kotlin + Jetpack Compose + Material 3)  
**Primary Language:** Bengali (`bn-BD`). English and Hindi are optional secondary languages.

---

## Architecture & Key Modules

- **`ui/components/AiOrbVisualizer.kt` & `CompanionStage.kt`**: Modern iOS-inspired white/deep-emerald & champagne-gold glassmorphic interface featuring a 6-state **Animated AI Orb** (`Idle`, `Listening`, `Processing`, `Speaking`, `Executing`, `Error`) toggleable with the expressive **3D-styled Character Stage**.
- **`data/ai/` (`TdbAiRepository.kt`, `DirectGeminiClient.kt`) & `security/SecurityManager.kt`**: Dual AI engine supporting zero-config **Firebase AI Logic (`Firebase.ai` + App Check)** by default PLUS optional **Personal Gemini API Key** mode stored in **Android Keystore (`AES-256-GCM`)**, with model selection, live connection testing, and detailed HTTP/key error diagnostics.
- **`voice/WakeWordForegroundService.kt` & `platform/AndroidDeviceBridge.kt`**: Opt-in Foreground Microphone Service listening for `"Hey TDB"`, `"Hello TDB"`, `"হ্যালো টিডিবি"`, and `"এই TDB"`, responding with `"জি, বলো। কী করতে পারি?"` and launching voice input; paired with selectable **Male / Female Android TTS** voices with speed, pitch, volume, engine selection, and Test Voice playback.
- **`automation/TdbAccessibilityService.kt` & `domain/MobileCommandParser.kt`**: Android Accessibility helper & natural Bangla/English command parser for phone navigation (Back, Home/Close, Scroll Up/Down, Volume, Brightness, Wi-Fi/Bluetooth/Settings/Notes) and visible YouTube playback/screen controls (Search, Play/Pause/Resume/Next/Prev, First Video, Fullscreen, Mute/Unmute, Comments, Description, Speed).
- **`ui/screens/CompanionChatScreen.kt` & `AutomationToolsPane.kt`**: Interactive multi-step **WhatsApp, SMS, and Phone Call confirmation cards** (resolving contacts locally via `READ_CONTACTS` and requiring explicit user approval before opening WhatsApp drafts, SMS composer, or Phone Dialer), plus HTTPS webpage summarization (`summarizeWebUrl`), installed app launcher, SAF (`OpenDocument`) file viewer/sharer, and `StatFs` storage monitor.
- **`ui/components/CameraVisionSheet.kt` (`TdbVisionScreen`)**: Camera2 live preview with visible `CAMERA LIVE` indicator, frame capture, Android Photo Picker fallback, scene analysis, and OCR text extraction via Gemini Vision.
- **`ui/screens/ProductivityPane.kt` & `notifications/TdbReminderReceiver.kt`**: Daily (24h), Weekly (7d), and Monthly (30d) `UsageStatsManager` analytics, Productivity Score, Pomodoro Focus/Break timer, Daily Goals (`Study`, `Work`, `Business`, `Personal`) with scheduled `AlarmManager` notifications, and manual Activity Logs.
- **`data/local/` (`TdbDatabase.kt`, `TdbEntities.kt`, `TdbLocalRepository.kt`) & `ui/screens/MemoriesScreen.kt`**: Device-local Room v2 database supporting searchable, editable, deletable, and exportable memories across **11 categories**.

---

## Permissions Guide (Opt-In & Play-Compliant)

| Permission / Access | Purpose | When Requested |
| :--- | :--- | :--- |
| `INTERNET` | Gemini AI calls & webpage summarization | Install-time |
| `RECORD_AUDIO` + `FOREGROUND_SERVICE_MICROPHONE` | Voice dictation & optional `"Hey TDB"` wake-word listener | On tapping Mic or enabling Wake Word switch |
| `POST_NOTIFICATIONS` | Wake-word active notification & goal/focus reminders | Android 13+ when enabling Wake Word |
| `CAMERA` | Live `TdbVisionScreen` preview & capture | On tapping Start Camera in Vision tab |
| `READ_CONTACTS` | Resolving contact names for WhatsApp, SMS, or Phone Dialer | Only when sending/calling by contact name |
| `PACKAGE_USAGE_STATS` (Special Access) | Daily/Weekly/Monthly screen usage summary | Optional opt-in via System Settings |
| Accessibility Service (`TdbAccessibilityService`) | Scroll, Back/Home & visible YouTube UI button clicks | Optional opt-in via Android Accessibility Settings |

---

## Installation & Build Instructions

1. **Android Studio / CLI Build**:
   - AGP `9.1.1`, Gradle `9.3.1`, Kotlin `2.2.10`, `compileSdk = 36`, `minSdk = 26`.
   - Build debug APK: `gradle :app:assembleDebug`
   - Run unit & Robolectric tests: `gradle :app:testDebugUnitTest`
2. **GitHub Actions CI**:
   - `.github/workflows/build-apk.yml` automatically builds `app-debug.apk` on pushes to `main` and publishes it to GitHub Releases.
3. **Optional Personal Gemini API Key**:
   - Built-in **Firebase AI Logic** works immediately without entering a key.
   - To use your own key, open **Settings -> API Settings**, paste your key (placeholder `YOUR_GEMINI_API_KEY_HERE`), tap **Save & Test**, and verify connection diagnostics.

---

## Known Limitations & Platform Constraints

- **Always-Available Wake Word**: Uses Android `SpeechRecognizer` inside a visible `ForegroundService` rather than an offline C++ hotword binary; accuracy, battery usage, and continuous recognition depend on the device's speech recognition provider and manufacturer battery optimizations.
- **YouTube Direct Seeking & UI Controls**: Public Android Intents/`MediaSession` do not permit arbitrary timestamp seeking (`2 minute`) inside the official YouTube app, and Accessibility-based button taps (`Full Screen`, `Comments`, `Description`, `2x`) depend on those UI controls currently being visible on screen.
- **Messaging & Phone Calls**: For user safety and Android policy compliance, WhatsApp (`wa.me`), SMS (`smsto:`), and Phone Dialer (`tel:`) open pre-filled drafts/dialer after explicit in-app confirmation rather than silently sending messages or placing background calls.
- **System Brightness**: Changing screen brightness directly requires `WRITE_SETTINGS` permission; if not granted, TDB opens Android Display Settings instead.

---

## Verification & Testing Report

- Build/test results must be confirmed by running the workflow for this repository version; this editing environment does not include Gradle or the Android SDK.
- Run `gradle :app:testDebugUnitTest` in Android Studio or GitHub Actions to verify unit and Robolectric tests.
  - `TdbCommandAndIdentityTest` (6 tests): Wake-word matching, Bangla/English command parsing, YouTube & Phone controls, WhatsApp/SMS/Call flows, `TdbPersonality` (`Deep Barmon`, `TDB`, `Deep Barmon Bhai Vlog`, no `TDP`), and key/model validation.
  - `TdbRobolectricAppTest` (5 tests, `@Config(sdk = [36])`): App resource verification, Android `JSONObject` Gemini HTTP diagnostic mapping, Room in-memory CRUD (`TdbLocalRepository` add/edit/delete/export + productivity score), and Jetpack Compose UI tests for `AiOrbVisualizer` and `MemoriesScreen` search filtering.